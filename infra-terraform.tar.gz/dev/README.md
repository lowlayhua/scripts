# Dev Infrastructure

Use this folder to store any related infrastructure for dev environment

## Prerequisites

- Have terraform installed
- Have proper AWS credentials setup

## How To

- Run `terraform init` to initialize your local environment
- Create new tf file (for example: `main.tf`) and add resource into it.
- AWS terraform document could be found here https://registry.terraform.io/providers/hashicorp/aws/latest/docs
- Have fun!
