# API Gateway Terraform Module

A terraform module to spin up api gateway & related resources.
See: https://vungle.atlassian.net/wiki/spaces/SRE/pages/1564377238/API+Gateway+-+Lumbergh for more information on the detailed setup.

Co-work with the [Lambda Authorizer terraform module](../lambda-authorizer)

## Example

```hcl
### API Gateway
module "apigateway" {
  source      = "../modules/apigateway"
  service     = "lumbergh"
  environment = "dev"
  region      = "us-west-2"

  aws_certificate_arn = data.aws_acm_certificate.vungle_io.arn
  domain_name         = "lumbergh-dev.vungle.io"
  backend_endpoint    = "https://adv-manage-qa-api.vungle.io"
  authorizer_uri      = module.lambda.arn
}
```

## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| aws  | n/a     |

## Inputs

| Name                             | Description                            | Type     | Default                                                                                                                                                                                                                                                                                                                                                          | Required |
|----------------------------------|----------------------------------------|----------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|:--------:|
| authorization                    | n/a                                    | `string` | `"CUSTOM"`                                                                                                                                                                                                                                                                                                                                                       |    no    |
| authorizer\_uri                  | n/a                                    | `string` | `"arn:aws:lambda:us-west-2:320005014399:function:vungle-lumbergh-qa"`                                                                                                                                                                                                                                                                                            |    no    |
| aws\_certificate\_arn            | n/a                                    | `any`    | n/a                                                                                                                                                                                                                                                                                                                                                              |   yes    |
| backend\_endpoint                | n/a                                    | `string` | `"https://example.com"`                                                                                                                                                                                                                                                                                                                                          |    no    |
| burst\_limit                     | n/a                                    | `string` | `"5000"`                                                                                                                                                                                                                                                                                                                                                         |    no    |
| domain\_name                     | n/a                                    | `any`    | n/a                                                                                                                                                                                                                                                                                                                                                              |   yes    |
| environment                      | n/a                                    | `any`    | n/a                                                                                                                                                                                                                                                                                                                                                              |   yes    |
| integration\_request\_parameters | default integration request parameters | `map`    | <pre>{<br>  "integration.request.header.Authorization": "method.request.header.Authorization",<br>  "integration.request.header.vungle-api-key": "method.request.header.vungle-api-key",<br>  "integration.request.header.vungle-version": "method.request.header.vungle-version",<br>  "integration.request.path.proxy": "method.request.path.proxy"<br>}</pre> |    no    |
| method\_request\_parameters      | default method request parameters      | `map`    | <pre>{<br>  "method.request.header.Authorization": false,<br>  "method.request.header.vungle-api-key": false,<br>  "method.request.header.vungle-version": false,<br>  "method.request.path.proxy": true<br>}</pre>                                                                                                                                              |    no    |
| rate\_limit                      | n/a                                    | `string` | `"10000"`                                                                                                                                                                                                                                                                                                                                                        |    no    |
| region                           | n/a                                    | `string` | `"us-west-2"`                                                                                                                                                                                                                                                                                                                                                    |    no    |
| service                          | n/a                                    | `any`    | n/a                                                                                                                                                                                                                                                                                                                                                              |   yes    |

## Outputs

| Name                   | Description |
|------------------------|-------------|
| domain\_name           | n/a         |
| execution\_arn         | n/a         |
| regional\_domain\_name | n/a         |
| zone\_id               | n/a         |
