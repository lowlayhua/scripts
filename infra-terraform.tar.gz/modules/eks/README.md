# Terraform eks module

A terraform module to create a managed Kubernetes cluster on AWS EKS

## Assumptions

* You want to create an EKS cluster with all necessary dependencies
* You want these resources to exist within security groups that allow communication and coordination. These can be user provided or created within the module.
* You've created a Virtual Private Cloud (VPC) and subnets where you intend to put the EKS resources. The VPC satisfies [EKS requirements](https://docs.aws.amazon.com/eks/latest/userguide/network_reqs.html).

## Usage example

See: [eks-stage-1a](../../eks-stage-1a/)

```hcl
terraform {
  required_version = ">= 0.12"

  backend "s3" {
    bucket         = "vungle-sre-terraform-state"
    key            = "infra_eks_stage_1a"
    region         = "us-east-1"
    dynamodb_table = "sre_terraform_state"
  }

}

provider "aws" {
  region = "us-east-1"
}

module "eks" {
  source = "../modules/eks"

  namespace   = "eks"
  environment = "stage"
  name        = "1a"
  region      = "us-east-1"

  vpc_id   = "vpc-285b904f"
  vpc_cidr = "172.20.0.0/16"

  public_subnets = {
    "eks-stage-1a-public-1" = {
      cidr_block        = "172.20.196.0/24"
      availability_zone = "us-east-1a"
    },
    "eks-stage-1a-public-2" = {
      cidr_block        = "172.20.197.0/25"
      availability_zone = "us-east-1f"
    },
  }

  private_subnets = {
    "eks-stage-1a-private-1" = {
      cidr_block        = "172.20.192.0/22"
      availability_zone = "us-east-1a"
    },
    "eks-stage-1a-private-2" = {
      cidr_block        = "172.20.197.128/25"
      availability_zone = "us-east-1f"
    },
    "eks-stage-1a-private-3" = {
      cidr_block        = "172.20.198.0/23"
      availability_zone = "us-east-1a"
    },
  }
}

```

## Requirements

| Name      | Version |
|-----------|---------|
| terraform | >= 0.12 |

## Providers

| Name     | Version |
|----------|---------|
| aws      | n/a     |
| spotinst | n/a     |
| tls      | n/a     |

## Inputs

| Name                        | Description | Type     | Default       | Required |
|-----------------------------|-------------|----------|---------------|:--------:|
| cluster\_version            | n/a         | `string` | `"1.15"`      |    no    |
| environment                 | n/a         | `any`    | n/a           |   yes    |
| name                        | n/a         | `any`    | n/a           |   yes    |
| namespace                   | n/a         | `any`    | n/a           |   yes    |
| private\_subnets            | n/a         | `map`    | n/a           |   yes    |
| public\_subnets             | n/a         | `map`    | n/a           |   yes    |
| region                      | n/a         | `string` | `"us-east-1"` |    no    |
| spotinst\_desired\_capacity | n/a         | `number` | `20`          |    no    |
| spotinst\_max\_size         | n/a         | `number` | `100`         |    no    |
| spotinst\_min\_size         | n/a         | `number` | `10`          |    no    |
| spotinst\_percentage        | n/a         | `number` | `100`         |    no    |
| vpc\_cidr                   | n/a         | `any`    | n/a           |   yes    |
| vpc\_id                     | n/a         | `any`    | n/a           |   yes    |

## Outputs

| Name                      | Description |
|---------------------------|-------------|
| eks\_node\_iam\_role\_arn | n/a         |
| endpoint                  | n/a         |
