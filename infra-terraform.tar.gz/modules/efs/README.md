## About
A Small terraform module to create efs-related resources.


## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| aws | n/a |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| environment | n/a | `string` | `"prod"` | no |
| region | n/a | `any` | n/a | yes |
| subnet\_ids | n/a | `list` | n/a | yes |
| vpc\_id | n/a | `any` | n/a | yes |

## Outputs

No output.

