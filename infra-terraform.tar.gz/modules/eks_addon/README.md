# Terraform eks addon module

A terraform module to install additional components to Kubernetes cluster

## Assumptions

* You have a newly-created Kubernetes cluster with nothing inside
* You want to install all extra components in one run:
  * spotinst controller
  * tiller (helm)
  * aws-auth configmap for user authentication
  * nginx-ingress
  * metrics-server
  
## Usage example

See: [eks-stage-1a-addon](../../eks-stage-1a-addon/)

```hcl
terraform {
  required_version = ">= 0.12"

  backend "s3" {
    bucket         = "vungle-sre-terraform-state"
    key            = "infra_eks_stage_1a_addon"
    region         = "us-east-1"
    dynamodb_table = "sre_terraform_state"
  }

  required_providers {
    helm = "~> 0.10.4"
  }
}

provider "aws" {
  region = "us-east-1"
}

provider "kubernetes" {
  host                   = data.aws_eks_cluster.eks.endpoint
  cluster_ca_certificate = base64decode(data.aws_eks_cluster.eks.certificate_authority.0.data)
  token                  = data.aws_eks_cluster_auth.eks.token
  load_config_file       = false
  version                = "~> 1.11"
}

provider "helm" {
  kubernetes {
    host                   = data.aws_eks_cluster.eks.endpoint
    cluster_ca_certificate = base64decode(data.aws_eks_cluster.eks.certificate_authority.0.data)
    token                  = data.aws_eks_cluster_auth.eks.token
    load_config_file       = false
  }
}

data "aws_eks_cluster" "eks" {
  name = "eks-stage-1a"
}

data "aws_eks_cluster_auth" "eks" {
  name = "eks-stage-1a"
}

module "eks_addon" {
  source = "../modules/eks_addon"

  namespace   = "eks"
  environment = "stage"
  name        = "1a"
  region      = "us-east-1"
}
```

## Requirements

| Name      | Version   |
|-----------|-----------|
| terraform | >= 0.12   |
| helm      | ~> 0.10.4 |

## Providers

| Name       | Version   |
|------------|-----------|
| aws        | n/a       |
| helm       | ~> 0.10.4 |
| kubernetes | n/a       |
| sops       | n/a       |

## Inputs

| Name                   | Description                                            | Type                                                                                                               | Default                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              | Required |
|------------------------|--------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|:--------:|
| environment            | n/a                                                    | `any`                                                                                                              | n/a                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |   yes    |
| map\_extra\_users      | Addtional IAM users to add to the aws-auth configmap.  | <pre>list(object({<br>    userarn  = string<br>    username = string<br>    groups   = list(string)<br>  }))</pre> | `[]`                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |    no    |
| map\_roles             | Additional IAM roles to add to the aws-auth configmap. | <pre>list(object({<br>    rolearn  = string<br>    username = string<br>    groups   = list(string)<br>  }))</pre> | <pre>[<br>  {<br>    "groups": [<br>      "system:masters"<br>    ],<br>    "rolearn": "arn:aws:iam::66666666666:role/role1",<br>    "username": "role1"<br>  }<br>]</pre>                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |    no    |
| map\_users             | Default IAM users to add to the aws-auth configmap.    | <pre>list(object({<br>    userarn  = string<br>    username = string<br>    groups   = list(string)<br>  }))</pre> | <pre>[<br>  {<br>    "groups": [<br>      "system:masters"<br>    ],<br>    "userarn": "arn:aws:iam::320005014399:user/eks-jenkins",<br>    "username": "eks-jenkins"<br>  },<br>  {<br>    "groups": [<br>      "system:masters"<br>    ],<br>    "userarn": "arn:aws:iam::320005014399:user/yang.wang",<br>    "username": "yang.wang"<br>  },<br>  {<br>    "groups": [<br>      "system:masters"<br>    ],<br>    "userarn": "arn:aws:iam::320005014399:user/harvey.liu",<br>    "username": "harvey.liu"<br>  },<br>  {<br>    "groups": [<br>      "system:masters"<br>    ],<br>    "userarn": "arn:aws:iam::320005014399:user/yaniv.hakim@vungle.com",<br>    "username": "yaniv.hakim@vungle.com"<br>  },<br>  {<br>    "groups": [<br>      "system:masters"<br>    ],<br>    "userarn": "arn:aws:iam::320005014399:user/surya.dharma",<br>    "username": "surya.dharma"<br>  },<br>  {<br>    "groups": [<br>      "system:masters"<br>    ],<br>    "userarn": "arn:aws:iam::320005014399:user/mayur.bhatia@vungle.com",<br>    "username": "mayur.bhatia@vungle.com"<br>  }<br>]</pre> |    no    |
| name                   | n/a                                                    | `any`                                                                                                              | n/a                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |   yes    |
| namespace              | n/a                                                    | `any`                                                                                                              | n/a                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |   yes    |
| region                 | n/a                                                    | `string`                                                                                                           | `"us-east-1"`                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |    no    |
| spotinst\_secret\_path | n/a                                                    | `string`                                                                                                           | `""`                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |    no    |
| tiller\_version        | helm tiller version                                    | `string`                                                                                                           | `"v2.16.6"`                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |    no    |

## Outputs

No output.
