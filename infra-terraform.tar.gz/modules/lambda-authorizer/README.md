# Lambda Authorizer Terraform Module

To be use with [API Gateway Terraform module](../apigateway)
See: https://vungle.atlassian.net/wiki/spaces/SRE/pages/1564377238/API+Gateway+-+Lumbergh

## Example

```hcl
### Lambda Authorizer ###

module "lambda" {
  source      = "../modules/lambda-authorizer"
  service     = "lumbergh"
  environment = "dev"
  secrets = {
    MONGO_USERNAME = ""
    MONGO_PASSWORD = ""
    JWT_SECRET     = ""
    MONGO_URI      = ""
  }

}
```

## Providers

| Name | Version |
|------|---------|
| aws  | n/a     |

## Inputs

| Name        | Description | Type     | Default                | Required |
|-------------|-------------|----------|------------------------|:--------:|
| code\_path  | n/a         | `string` | `"v1.0.6/code.zip"`    |    no    |
| environment | n/a         | `any`    | n/a                    |   yes    |
| handler     | n/a         | `string` | `"index.handler"`      |    no    |
| region      | n/a         | `string` | `"us-west-2"`          |    no    |
| runtime     | n/a         | `string` | `"nodejs12.x"`         |    no    |
| s3\_bucket  | n/a         | `string` | `"vungle-lumbergh-qa"` |    no    |
| secrets     | n/a         | `map`    | n/a                    |   yes    |
| service     | n/a         | `any`    | n/a                    |   yes    |

## Outputs

| Name | Description |
|------|-------------|
| arn  | n/a         |
| name | n/a         |
