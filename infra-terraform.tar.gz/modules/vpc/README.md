## About

A module to create AWS VPC with necessary components:

- VPC
- Default security group
- DHCP option
- Internet gateway
- S3 vpc endpoint
- DynamoDB vpc endpoint
- Shared public subnet (/24)
- Public route table

## Sample Usage

```hcl
module "vpc" {
  source             = "../modules/vpc"
  namespace          = "vpc"
  environment        = "dev"
  name               = "dev-us-east-1"
  vpc_cidr           = "10.0.0.0/16"
  shared_public_cidr = "10.0.0.0/24"
  shared_public_az   = "us-west-2a"
  region             = "us-west-2"
}
```

## Requirements

| Name | Version |
|------|---------|
| terraform | >= 0.13 |

## Providers

| Name | Version |
|------|---------|
| aws | n/a |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| environment | n/a | `any` | n/a | yes |
| name | n/a | `any` | n/a | yes |
| namespace | n/a | `any` | n/a | yes |
| region | n/a | `any` | n/a | yes |
| shared\_public\_az | n/a | `any` | n/a | yes |
| shared\_public\_cidr | n/a | `any` | n/a | yes |
| vpc\_cidr | n/a | `any` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| vpc\_id | n/a |
