#Terraform Load Balancer module

A terraform module to create a Load Balancer along with Security group, Target group and Listener groups.

##Assumptions

- You want to create Load Balancer, Security group, Target group and Listeners.
- You want these resources to exist and allow communication and coordination.
- You've created a Virtual Private Cloud (VPC) and subnets where you intend to create these resources.

##Usage Example
````
terraform {
  required_version = ">= 0.12"
}

provider "aws" {
  region = "us-east-1"
}

module "aws_lb_medivh" {
  source = "modules/aws_lb/"

  namespace   = "medivh"
  environment = "production"
  attribute   = ["ext"]
  vpc_id      = "vpc-80569de7"

  subnet_ids = [
    "subnet-0f176f57",
    "subnet-5aa68667",
  "subnet-fa28048c"]

  lb_internal = false
  lb_type     = "application"
  cluster     = "medivh"

  lb_arn = module.aws_lb_medivh.lb_arn

  security_groups = module.aws_lb_medivh.security_group_id

  tg_port              = 6688
  tg_protocol          = "HTTP"
  deregistration_delay = 300
  healthcheck_path     = "/_health"
  target_type          = "instance"
  create_route53_record = true       # If set to true creates route53 records, if want to set true also specify three more variables r53_record_type, r53_zone_id and r53_record_name. If false, no need to set the three variables.

  tg_targets = ({
    target_1 = {
      target_arn = module.aws_lb_medivh.tg_arn
      target_id  = "i-017eb92d182eb72d0"
      port       = 7000
    }
    target_2 = {
      target_arn = module.aws_lb_medivh.tg_arn
      target_id  = "i-0b383fb1aa5805ef2"
      port       = 7000
    }
  })

  listeners = ({
    http = {
      port                     = "80"
      protocol                 = "HTTP"
      ssl_policy               = ""
      listener_certificate_arn = ""
    },
    https = {
      port                     = "443"
      protocol                 = "HTTPS",
      ssl_policy               = "ELBSecurityPolicy-2016-08"
      listener_certificate_arn = "arn:aws:iam::320005014399:server-certificate/vungle_io_wildcard_20210502"
    }
  })
}

````
## Requirements

| Name      | Version |
|-----------|---------|
| terraform | >= 0.12 |

## Providers

| Name     | Version |
|----------|---------|
| aws      | n/a     |

## Inputs

| Name                        | Description | Type     | Default       | Required |
|-----------------------------|-------------|----------|---------------|:--------:|
| cluster                     | n/a         | `string` | n/a           |   yes    |
| environment                 | n/a         | `string` | n/a           |   yes    |
| name                        | n/a         | `string` | n/a           |   yes    |
| namespace                   | n/a         | `string` | null          |    no    |
| subnet\_ids                 | n/a         | `list`   | n/a           |   yes    |
| vpc\_id                     | n/a         | `string` | n/a           |   yes    |
| lb\_type                    | n/a         | `string` | n/a           |   yes    |
| lb\_internal                | n/a         | `string` | n/a           |   yes    |
| security\_groups            | n/a         | `string` | null          |    no    |
| tg\_port                    | n/a         | `number` | n/a           |   yes    |
| tg\_protocol                | n/a         | `string` | n/a           |   yes    |
| tg\_targets                 | n/a         | `string` | null          |    no    |
| healthcheck\_path           | n/a         | `string` | n/a           |   yes    |
| healthy\_threshold          | n/a         | `number` | `3`           |    no    |
| unhealthy\_threshold        | n/a         | `number` | `3`           |    no    |
| timeout                     | n/a         | `number` | `10`          |    no    |
| interval                    | n/a         | `number` | `30`          |    no    |
| success\_codes              | n/a         | `string` | `200-399`     |    no    |
| deregistration\_delay       | n/a         | `number` | `300`         |    no    |
| target\_type                | n/a         | `string` | n/a           |   yes    |
| lb\_algorithm_type          | n/a         | `string` | `round_robin` |    no    |
| lb\_arn                     | n/a         | `string` | `100`         |    no    |
| tg\_arn                     | n/a         | `string` | null          |    no    |
| listeners                   | n/a         | `map`    | `80,443`      |    no    |
| create\_route53\_record     | n/a         | `string` | n/a           |    yes    |

## Outputs

| Name                      | Description |
|---------------------------|-------------|
| lb\_arn                   | n/a         |
| lb\_name                  | n/a         |
| listener\_arn             | n/a         |
| security\_group\_id       | n/a         |
| security\_group\_name     | n/a         |
| tg\_arn                   | n/a         |
| tg\_name                  | n/a         |
| route53\_record           | n/a         |




